package com.example.mytabdemoapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ExpandableListView elv = (ExpandableListView) findViewById(R.id.expandable);
        final ArrayList<Country_name> country = getData();
        CustomAdapter adapter = new CustomAdapter(this, country);
        elv.setAdapter(adapter);
        elv.setOnChildClickListener(new OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPos,
                                        int childPos, long id) {
                Toast.makeText(getApplicationContext(), country.get(groupPos).country_name.get(childPos), Toast.LENGTH_SHORT).show();
                return false;
            }
        });
    }
    private ArrayList<Country_name> getData() {
        Country_name t1 = new Country_name("Football Teams Ranked");
        t1.country_name.add("Belgium");
        t1.country_name.add("Brazil");
        t1.country_name.add("France");
        t1.country_name.add("England");
        t1.country_name.add("Argentina");
        Country_name t2 = new Country_name("Cricket Teams Ranked");
        t2.country_name.add("New Zealand");
        t2.country_name.add("England");
        t2.country_name.add("India");
        t2.country_name.add("South Africa");
        t2.country_name.add("Pakistan");
        t2.country_name.add("Bangladesh");
        Country_name t3 = new Country_name("Basketball Teams Ranked");
        t3.country_name.add("USA");
        t3.country_name.add("Spain");
        t3.country_name.add("Australia");
        t3.country_name.add("Slovenia");
        t3.country_name.add("France");
        Country_name t4 = new Country_name("Badminton Teams Ranked");
        t4.country_name.add("Denmark");
        t4.country_name.add("Japan");
        t4.country_name.add("Indonesia");
        t4.country_name.add("China");
        ArrayList<Country_name> allcountry = new ArrayList<Country_name>();
        allcountry.add(t1);
        allcountry.add(t2);
        allcountry.add(t3);
        allcountry.add(t4);
        return allcountry;
    }
}
// Thanks for visiting Learning dot bd
