package com.example.mytabdemoapp;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
public class CustomAdapter extends BaseExpandableListAdapter {
    private Context c;
    private ArrayList<Country_name> Country_name;
    private LayoutInflater inflater;
    public CustomAdapter(Context c, ArrayList<Country_name> Country_name) {
        this.c = c;
        this.Country_name = Country_name;
        inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public Object getChild(int groupPos, int childPos) {
        // TODO Auto-generated method stub
        return Country_name.get(groupPos).country_name.get(childPos);
    }
    @Override
    public long getChildId(int arg0, int arg1) {
        // TODO Auto-generated method stub
        return 0;
    }
    @Override
    public View getChildView(int groupPos, int childPos, boolean isLastChild, View convertlayout,
                             ViewGroup parent) {
        if (convertlayout == null) {
            convertlayout = inflater.inflate(R.layout.list_item, null);
        }
        String child = (String) getChild(groupPos, childPos);
        TextView nameTv = (TextView) convertlayout.findViewById(R.id.item_text);
        ImageView img = (ImageView) convertlayout.findViewById(R.id.item_image);
        nameTv.setText(child);
        String teamName = getGroup(groupPos).toString();
        if (teamName == "Football Teams Ranked") {
            if (child == "Belgium") {
                img.setImageResource(R.drawable.belgium);
            } else if (child == "Brazil") {
                img.setImageResource(R.drawable.brazil);
            } else if (child == "France") {
                img.setImageResource(R.drawable.france);
            } else if (child == "England") {
                img.setImageResource(R.drawable.england);
            } else if (child == "Argentina") {
                img.setImageResource(R.drawable.argentina);
            }
        } else if (teamName == "Cricket Teams Ranked") {
            if (child == "New Zealand") {
                img.setImageResource(R.drawable.newzealand);
            } else if (child == "England") {
                img.setImageResource(R.drawable.england);
            } else if (child == "India") {
                img.setImageResource(R.drawable.india);
            } else if (child == "South Africa") {
                img.setImageResource(R.drawable.southafrica);
            } else if (child == "Pakistan") {
                img.setImageResource(R.drawable.pakistan);
            } else if (child == "Bangladesh") {
                img.setImageResource(R.drawable.bangladesh);
            }
        } else if (teamName == "Basketball Teams Ranked") {
            if (child == "USA") {
                img.setImageResource(R.drawable.usa);
            } else if (child == "Spain") {
                img.setImageResource(R.drawable.spain);
            } else if (child == "Australia") {
                img.setImageResource(R.drawable.australia);
            } else if (child == "Slovenia") {
                img.setImageResource(R.drawable.slovenia);
            } else if (child == "France") {
                img.setImageResource(R.drawable.france);
            }
        } else if (teamName == "Badminton Teams Ranked") {
            if (child == "Denmark") {
                img.setImageResource(R.drawable.denmark);
            } else if (child == "Japan") {
                img.setImageResource(R.drawable.japan);
            } else if (child == "Indonesia") {
                img.setImageResource(R.drawable.indonesia);
            } else if (child == "China") {
                img.setImageResource(R.drawable.china);
            }
        }
        return convertlayout;
    }
    @Override
    public int getChildrenCount(int groupPosw) {
        return Country_name.get(groupPosw).country_name.size();
    }
    @Override
    public Object getGroup(int groupPos) {
        return Country_name.get(groupPos);
    }
    @Override
    public int getGroupCount() {
        return Country_name.size();
    }
    @Override
    public long getGroupId(int arg0) {
        return 0;
    }
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertlayout, ViewGroup parent) {
        if (convertlayout == null) {
            convertlayout = inflater.inflate(R.layout.group, null);
        }
        Country_name t = (Country_name) getGroup(groupPosition);
        TextView nameTv = (TextView) convertlayout.findViewById(R.id.group_text);
        ImageView img = (ImageView) convertlayout.findViewById(R.id.group_image);
        String Team = t.Team;
        nameTv.setText(Team);
        convertlayout.setBackgroundColor(Color.LTGRAY);
        return convertlayout;
    }
    @Override
    public boolean isChildSelectable( int arg1,int arg0) {
        return true;
    }
    @Override
    public boolean hasStableIds() {
        return false;
    }
}
