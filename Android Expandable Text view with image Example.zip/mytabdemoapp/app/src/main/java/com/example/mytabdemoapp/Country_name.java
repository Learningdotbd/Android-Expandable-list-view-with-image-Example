package com.example.mytabdemoapp;

import java.util.ArrayList;

public class Country_name {
    public String Team;
    public String Image;
    public ArrayList<String> country_name = new ArrayList<String>();
    @Override
    public String toString() {
        return Team;
    }public Country_name(String Name) {
        this.Team = Name;
    }}
